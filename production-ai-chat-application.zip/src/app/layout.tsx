import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Aster — Your AI workspace",
  description: "A private, flexible AI chat workspace. Connect your own providers, discover models automatically, and chat with live web search.",
  applicationName: "Aster",
};

export const viewport: Viewport = { themeColor: "#fdfdfc" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">{children}</body>
    </html>
  );
}
