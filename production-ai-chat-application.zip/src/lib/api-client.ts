import type { ModelInfo, ProviderDraft, SearchEngine, SearchResult } from "@/lib/types";

export class ApiRequestError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
    this.name = "ApiRequestError";
  }
}

async function responseError(response: Response): Promise<ApiRequestError> {
  let message = `Request failed (${response.status}).`;
  try {
    const body = await response.json();
    if (typeof body.error === "string") message = body.error;
    else if (typeof body.error?.message === "string") message = body.error.message;
  } catch {
    // The upstream may have returned an empty or non-JSON error body.
  }
  if (response.status === 429 && !/rate limit|too many|quota/i.test(message)) {
    message = `Rate limit reached. ${message}`;
  }
  return new ApiRequestError(message, response.status);
}

export async function fetchProviderModels(
  provider: Pick<ProviderDraft, "baseUrl" | "apiKey">,
  signal?: AbortSignal,
): Promise<ModelInfo[]> {
  const response = await fetch("/api/models", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(provider),
    signal,
  });
  if (!response.ok) throw await responseError(response);
  const data: { models: ModelInfo[] } = await response.json();
  return data.models;
}

export async function searchWeb(
  query: string,
  engine: SearchEngine,
  apiKey: string,
  signal?: AbortSignal,
): Promise<SearchResult[]> {
  const response = await fetch("/api/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, engine, apiKey }),
    signal,
  });
  if (!response.ok) throw await responseError(response);
  const data: { results: SearchResult[] } = await response.json();
  return data.results;
}

type CompletionMessage = { role: "user" | "assistant"; content: string };

interface StreamOptions {
  baseUrl: string;
  apiKey: string;
  model: string;
  messages: CompletionMessage[];
  sources: SearchResult[];
  searchWasEnabled: boolean;
  onChunk: (text: string) => void;
  signal: AbortSignal;
}

function contentText(value: unknown): string {
  if (typeof value === "string") return value;
  if (Array.isArray(value)) {
    return value.map((part) => {
      if (typeof part === "string") return part;
      if (part && typeof part === "object" && "text" in part && typeof part.text === "string") return part.text;
      return "";
    }).join("");
  }
  return "";
}

/** Reads OpenAI-compatible SSE, including events split across arbitrary network chunks. */
export async function streamCompletion(options: StreamOptions): Promise<void> {
  const response = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      baseUrl: options.baseUrl,
      apiKey: options.apiKey,
      model: options.model,
      messages: options.messages,
      sources: options.sources,
      searchWasEnabled: options.searchWasEnabled,
    }),
    signal: options.signal,
  });
  if (!response.ok) throw await responseError(response);

  let received = "";
  if (response.headers.get("content-type")?.includes("application/json")) {
    const data = await response.json();
    if (data.error) {
      const message = typeof data.error === "string" ? data.error : data.error.message;
      throw new ApiRequestError(typeof message === "string" ? message : "The provider returned an error.");
    }
    const text = contentText(data.choices?.[0]?.message?.content);
    if (text) { received += text; options.onChunk(text); }
  } else {
    if (!response.body) throw new ApiRequestError("The provider returned an empty stream.");
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let finished = false;

    const processEvent = (event: string) => {
      const data = event.split(/\r?\n/)
        .filter((line) => line.startsWith("data:"))
        .map((line) => line.slice(5).trimStart())
        .join("\n").trim();
      if (!data) return;
      if (data === "[DONE]") { finished = true; return; }

      let payload: Record<string, unknown>;
      try { payload = JSON.parse(data); } catch { return; }
      if (payload.error) {
        const error = payload.error;
        const message = typeof error === "string" ? error
          : error && typeof error === "object" && "message" in error && typeof error.message === "string"
            ? error.message : "The provider reported a streaming error.";
        throw new ApiRequestError(message);
      }
      const choices = payload.choices as Array<{ delta?: { content?: unknown }; message?: { content?: unknown } }> | undefined;
      const text = contentText(choices?.[0]?.delta?.content ?? choices?.[0]?.message?.content);
      if (text) { received += text; options.onChunk(text); }
    };

    try {
      while (!finished) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let match = /\r?\n\r?\n/.exec(buffer);
        while (match) {
          const event = buffer.slice(0, match.index);
          buffer = buffer.slice(match.index + match[0].length);
          processEvent(event);
          if (finished) break;
          match = /\r?\n\r?\n/.exec(buffer);
        }
      }
      if (!finished && buffer.trim()) processEvent(buffer + decoder.decode());
      if (finished) await reader.cancel().catch(() => undefined);
    } finally {
      reader.releaseLock();
    }
  }

  if (!received.trim()) {
    throw new ApiRequestError("The provider finished without returning any message content. Try another chat-capable model.");
  }
}
