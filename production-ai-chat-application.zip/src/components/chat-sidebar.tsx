"use client";

import { useRef, useState, type KeyboardEvent } from "react";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { ChevronRight, Ellipsis, MessageSquare, Moon, PanelLeftClose, PenLine, Plus, Search, Settings2, Sun, Trash2 } from "lucide-react";
import { BrandMark } from "@/components/brand-mark";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { conversationGroup } from "@/lib/workspace";
import type { Conversation, ProviderConfig } from "@/lib/types";

interface ChatSidebarProps {
  conversations: Conversation[];
  activeId: string | null;
  providers: ProviderConfig[];
  dark: boolean;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onNewChat: () => void;
  onSelect: (id: string) => void;
  onRename: (id: string, title: string) => void;
  onDelete: (id: string) => void;
  onOpenSettings: () => void;
  onToggleTheme: () => void;
}

const groups = ["Today", "Yesterday", "Previous 7 days", "Older"];

export function ChatSidebar({ conversations, activeId, providers, dark, mobileOpen, onCloseMobile, onNewChat, onSelect, onRename, onDelete, onOpenSettings, onToggleTheme }: ChatSidebarProps) {
  const [query, setQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState("");
  const cancelRenameRef = useRef(false);
  const sorted = [...conversations]
    .filter((conversation) => !query.trim() || conversation.title.toLowerCase().includes(query.toLowerCase()) || conversation.messages.some((message) => message.content.toLowerCase().includes(query.toLowerCase())))
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

  function finishRename() {
    if (!editingId) return;
    if (cancelRenameRef.current) {
      cancelRenameRef.current = false;
      setEditingId(null);
      return;
    }
    const title = editingTitle.trim();
    if (title) onRename(editingId, title.slice(0, 100));
    setEditingId(null);
  }

  function renameKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Enter") { event.preventDefault(); finishRename(); }
    if (event.key === "Escape") { event.preventDefault(); cancelRenameRef.current = true; setEditingId(null); }
  }

  return (
    <aside className={cn(
      "fixed inset-y-0 left-0 z-40 flex w-[270px] shrink-0 flex-col border-r border-[var(--border)] bg-[var(--sidebar)] transition-transform duration-200 lg:relative lg:translate-x-0",
      mobileOpen ? "translate-x-0" : "-translate-x-full",
    )} aria-label="Conversation sidebar">
      <div className="flex h-[78px] shrink-0 items-center justify-between px-5">
        <div className="flex items-center gap-2.5"><BrandMark /><span className="text-[21px] font-bold tracking-[-0.065em] text-[var(--fg)]">aster<span className="text-[var(--accent)]">.</span></span></div>
        <button type="button" onClick={onCloseMobile} className="rounded-lg p-2 text-[var(--muted)] hover:bg-[var(--hover-bg)] lg:hidden" aria-label="Close sidebar"><PanelLeftClose className="h-5 w-5" /></button>
      </div>

      <div className="shrink-0 px-4 pb-5 pt-1">
        <Button onClick={onNewChat} className="h-11 w-full justify-start rounded-xl bg-[var(--fg)] px-3.5 text-[var(--surface)] shadow-none hover:bg-[var(--fg-soft)]">
          <Plus className="h-4 w-4" strokeWidth={2.3} /><span className="flex-1 text-left">New chat</span><span className="rounded-md border border-white/15 px-1.5 py-0.5 text-[10px] font-normal opacity-60">⌘ J</span>
        </Button>
      </div>

      <div className="shrink-0 px-4 pb-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[var(--muted)]" />
          <input type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search chats" aria-label="Search conversations" className="h-9 w-full rounded-lg border border-[var(--border)] bg-[var(--surface)] pl-9 pr-3 text-xs text-[var(--fg)] outline-none transition-colors placeholder:text-[var(--muted)] focus:border-[var(--accent)]" />
        </div>
      </div>

      <nav className="custom-scrollbar min-h-0 flex-1 overflow-y-auto px-3 pb-4" aria-label="Conversation history">
        {sorted.length === 0 ? (
          <div className="mx-2 mt-10 text-center">
            <div className="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--muted)]"><MessageSquare className="h-[18px] w-[18px]" /></div>
            <p className="text-xs font-medium text-[var(--fg)]">{query ? "No matching chats" : "No conversations yet"}</p>
            <p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">{query ? "Try a different search." : "Your chats will show up here."}</p>
          </div>
        ) : groups.map((group) => {
          const items = sorted.filter((conversation) => conversationGroup(conversation.updatedAt) === group);
          if (!items.length) return null;
          return (
            <div key={group} className="mb-5">
              <p className="px-3 pb-2 pt-2 text-[10px] font-semibold uppercase tracking-[0.13em] text-[var(--muted)]">{group}</p>
              <div className="space-y-0.5">
                {items.map((conversation) => (
                  <div key={conversation.id} className={cn("group relative flex h-10 items-center rounded-lg transition-colors hover:bg-[var(--hover-bg)]", activeId === conversation.id && "bg-[var(--selected-bg)] hover:bg-[var(--selected-bg)]")}>
                    {editingId === conversation.id ? (
                      <input autoFocus value={editingTitle} onChange={(event) => setEditingTitle(event.target.value)} onKeyDown={renameKeyDown} onBlur={finishRename} aria-label="Rename conversation" className="mx-2 w-full rounded-md border border-[var(--accent)] bg-[var(--surface)] px-2 py-1 text-xs outline-none" />
                    ) : (
                      <>
                        <button type="button" onClick={() => onSelect(conversation.id)} aria-current={activeId === conversation.id ? "page" : undefined} className={cn("flex h-full min-w-0 flex-1 items-center gap-2.5 pl-3 pr-1 text-left text-[12px] text-[var(--sidebar-text)]", activeId === conversation.id && "font-medium text-[var(--fg)]")}>
                          <MessageSquare className={cn("h-[15px] w-[15px] shrink-0 text-[var(--muted)]", activeId === conversation.id && "text-[var(--accent)]")} strokeWidth={1.7} />
                          <span className="truncate">{conversation.title}</span>
                        </button>
                        <DropdownMenu.Root>
                          <DropdownMenu.Trigger asChild>
                            <button type="button" aria-label={`Options for ${conversation.title}`} className="mr-1.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-[var(--muted)] opacity-0 transition-opacity hover:bg-[var(--surface)] hover:text-[var(--fg)] focus:opacity-100 group-hover:opacity-100 data-[state=open]:opacity-100"><Ellipsis className="h-4 w-4" /></button>
                          </DropdownMenu.Trigger>
                          <DropdownMenu.Portal>
                            <DropdownMenu.Content side="right" align="start" sideOffset={6} onCloseAutoFocus={(event) => event.preventDefault()} className="z-[60] min-w-[145px] rounded-xl border border-[var(--border)] bg-[var(--surface)] p-1 text-[var(--fg)] shadow-[0_10px_35px_rgba(20,20,30,0.16)]">
                              <DropdownMenu.Item onSelect={() => { cancelRenameRef.current = false; setEditingId(conversation.id); setEditingTitle(conversation.title); }} className="flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-xs outline-none focus:bg-[var(--hover-bg)]"><PenLine className="h-3.5 w-3.5" /> Rename</DropdownMenu.Item>
                              <DropdownMenu.Item onSelect={() => onDelete(conversation.id)} className="flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-xs text-red-500 outline-none focus:bg-red-50 dark:focus:bg-red-950/30"><Trash2 className="h-3.5 w-3.5" /> Delete</DropdownMenu.Item>
                            </DropdownMenu.Content>
                          </DropdownMenu.Portal>
                        </DropdownMenu.Root>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </nav>

      <div className="shrink-0 border-t border-[var(--border)] px-3 pb-4 pt-3">
        {providers.length === 0 && <button type="button" onClick={onOpenSettings} className="mb-3 flex w-full items-center gap-2.5 rounded-xl border border-[var(--accent)]/20 bg-[var(--accent-soft)] px-3 py-3 text-left transition-colors hover:bg-[var(--accent-soft-hover)]"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[var(--surface)] text-[var(--accent)]"><Plus className="h-4 w-4" /></span><span><span className="block text-xs font-semibold text-[var(--fg)]">Get started</span><span className="block text-[11px] text-[var(--muted)]">Connect your first API</span></span><ChevronRight className="ml-auto h-3.5 w-3.5 text-[var(--muted)]" /></button>}
        <button type="button" onClick={onOpenSettings} className="flex h-10 w-full items-center gap-3 rounded-lg px-3 text-left text-xs font-medium text-[var(--sidebar-text)] transition-colors hover:bg-[var(--hover-bg)] hover:text-[var(--fg)]"><Settings2 className="h-[17px] w-[17px] text-[var(--muted)]" /><span className="flex-1">Connections</span>{providers.length > 0 && <span className="rounded-md bg-[var(--surface)] px-1.5 py-0.5 text-[10px] text-[var(--muted)]">{providers.length}</span>}</button>
        <button type="button" onClick={onToggleTheme} className="flex h-10 w-full items-center gap-3 rounded-lg px-3 text-left text-xs font-medium text-[var(--sidebar-text)] transition-colors hover:bg-[var(--hover-bg)] hover:text-[var(--fg)]">{dark ? <Sun className="h-[17px] w-[17px] text-[var(--muted)]" /> : <Moon className="h-[17px] w-[17px] text-[var(--muted)]" />}<span>{dark ? "Light appearance" : "Dark appearance"}</span></button>
        <div className="mt-3 flex items-center gap-2 border-t border-[var(--border)] px-3 pt-4"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /><span className="text-[10px] text-[var(--muted)]">Your workspace, on this device</span></div>
      </div>
    </aside>
  );
}
