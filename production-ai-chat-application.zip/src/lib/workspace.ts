import type {
  ChatMessage,
  Conversation,
  ModelSelection,
  ProviderConfig,
  SearchEngine,
  ThemePreference,
  WorkspaceState,
} from "@/lib/types";

const STORAGE_KEY = "aster-workspace-v1";

export const emptyWorkspace: WorkspaceState = {
  providers: [],
  selectedModel: null,
  conversations: [],
  activeConversationId: null,
  webSearchEnabled: false,
  theme: "light",
};

export function resolveSelectedModel(
  providers: ProviderConfig[],
  preferred: ModelSelection | null,
): ModelSelection | null {
  if (
    preferred &&
    providers.some(
      (provider) =>
        provider.id === preferred.providerId &&
        provider.models.some((model) => model.id === preferred.modelId),
    )
  ) {
    return preferred;
  }

  for (const provider of providers) {
    if (provider.models.length > 0) {
      return { providerId: provider.id, modelId: provider.models[0].id };
    }
  }
  return null;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function readProviders(value: unknown): ProviderConfig[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((entry): ProviderConfig[] => {
    if (
      !isObject(entry) ||
      typeof entry.id !== "string" ||
      typeof entry.name !== "string" ||
      typeof entry.baseUrl !== "string" ||
      typeof entry.apiKey !== "string"
    ) return [];

    const models = Array.isArray(entry.models)
      ? entry.models.flatMap((model) =>
          isObject(model) && typeof model.id === "string"
            ? [{
                id: model.id,
                name: typeof model.name === "string" ? model.name : undefined,
                ownedBy: typeof model.ownedBy === "string" ? model.ownedBy : undefined,
              }]
            : [],
        )
      : [];

    const searchEngine: SearchEngine =
      entry.searchEngine === "tavily" || entry.searchEngine === "serpapi"
        ? entry.searchEngine
        : "brave";

    return [{
      id: entry.id,
      name: entry.name,
      baseUrl: entry.baseUrl,
      apiKey: entry.apiKey,
      searchEngine,
      searchApiKey: typeof entry.searchApiKey === "string" ? entry.searchApiKey : "",
      models,
      lastFetchedAt: typeof entry.lastFetchedAt === "string" ? entry.lastFetchedAt : undefined,
      modelError: typeof entry.modelError === "string" ? entry.modelError : undefined,
    }];
  });
}

function readConversations(value: unknown): Conversation[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((entry): Conversation[] => {
    if (!isObject(entry) || typeof entry.id !== "string") return [];

    const messages: ChatMessage[] = Array.isArray(entry.messages)
      ? entry.messages.flatMap((message): ChatMessage[] => {
          if (
            !isObject(message) ||
            typeof message.id !== "string" ||
            (message.role !== "user" && message.role !== "assistant") ||
            typeof message.content !== "string"
          ) return [];
          const status = message.status === "error" || message.status === "stopped"
            ? message.status
            : message.status === "streaming" ? "stopped" : "complete";
          return [{
            id: message.id,
            role: message.role,
            content: message.content,
            createdAt: typeof message.createdAt === "string" ? message.createdAt : new Date().toISOString(),
            status,
            modelId: typeof message.modelId === "string" ? message.modelId : undefined,
            providerName: typeof message.providerName === "string" ? message.providerName : undefined,
            citations: Array.isArray(message.citations)
              ? message.citations.filter((source): source is { title: string; url: string; snippet: string; domain: string } =>
                  isObject(source) &&
                  typeof source.title === "string" &&
                  typeof source.url === "string" &&
                  typeof source.snippet === "string" &&
                  typeof source.domain === "string",
                )
              : undefined,
            searchQuery: typeof message.searchQuery === "string" ? message.searchQuery : undefined,
            usedWebSearch: message.usedWebSearch === true,
            error: typeof message.error === "string" ? message.error : undefined,
          }];
        })
      : [];

    return [{
      id: entry.id,
      title: typeof entry.title === "string" ? entry.title : "Untitled conversation",
      createdAt: typeof entry.createdAt === "string" ? entry.createdAt : new Date().toISOString(),
      updatedAt: typeof entry.updatedAt === "string" ? entry.updatedAt : new Date().toISOString(),
      messages,
    }];
  });
}

/** Credentials and chats stay in this browser; nothing is persisted on the server. */
export function loadWorkspace(): WorkspaceState {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return emptyWorkspace;
    const parsed: unknown = JSON.parse(stored);
    if (!isObject(parsed) || parsed.version !== 1 || !isObject(parsed.state)) return emptyWorkspace;

    const state = parsed.state;
    const providers = readProviders(state.providers);
    const conversations = readConversations(state.conversations);
    const requestedSelection = isObject(state.selectedModel) &&
      typeof state.selectedModel.providerId === "string" &&
      typeof state.selectedModel.modelId === "string"
      ? { providerId: state.selectedModel.providerId, modelId: state.selectedModel.modelId }
      : null;
    const theme: ThemePreference = state.theme === "dark" || state.theme === "system"
      ? state.theme : "light";

    return {
      providers,
      conversations,
      selectedModel: resolveSelectedModel(providers, requestedSelection),
      activeConversationId: conversations.some((conversation) => conversation.id === state.activeConversationId)
        ? state.activeConversationId as string : null,
      webSearchEnabled: state.webSearchEnabled === true,
      theme,
    };
  } catch {
    return emptyWorkspace;
  }
}

export function saveWorkspace(state: WorkspaceState): boolean {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ version: 1, state }));
    return true;
  } catch {
    return false;
  }
}

export function makeConversationTitle(text: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  return clean.length > 54 ? `${clean.slice(0, 54).trimEnd()}…` : clean || "New conversation";
}

export function formatMessageTime(date: string): string {
  const value = new Date(date);
  return Number.isNaN(value.getTime()) ? "" : value.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

export function conversationGroup(date: string): string {
  const timestamp = new Date(date).getTime();
  if (!Number.isFinite(timestamp)) return "Older";
  const today = new Date();
  const midnight = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  if (timestamp >= midnight) return "Today";
  if (timestamp >= midnight - 86_400_000) return "Yesterday";
  if (timestamp >= midnight - 7 * 86_400_000) return "Previous 7 days";
  return "Older";
}
