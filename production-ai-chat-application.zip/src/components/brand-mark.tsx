import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

export function BrandMark({ size = "md", className }: { size?: "sm" | "md" | "lg"; className?: string }) {
  return (
    <span className={cn(
      "brand-mark inline-flex shrink-0 items-center justify-center rounded-[12px] text-white",
      size === "sm" ? "h-8 w-8 rounded-[10px]" : size === "lg" ? "h-[70px] w-[70px] rounded-[22px]" : "h-9 w-9",
      className,
    )} aria-hidden="true">
      <Sparkles className={size === "lg" ? "h-8 w-8" : size === "sm" ? "h-[17px] w-[17px]" : "h-5 w-5"} strokeWidth={1.9} />
    </span>
  );
}
