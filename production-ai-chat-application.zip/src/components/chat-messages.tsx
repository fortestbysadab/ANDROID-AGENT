"use client";

import { useState } from "react";
import { AlertCircle, Check, Copy, ExternalLink, Globe2, Pencil, RotateCcw, Square, UserRound } from "lucide-react";
import { toast } from "sonner";
import { BrandMark } from "@/components/brand-mark";
import { MarkdownContent } from "@/components/markdown-content";
import { Button } from "@/components/ui/button";
import { formatMessageTime } from "@/lib/workspace";
import type { ChatMessage, GenerationPhase, SearchResult } from "@/lib/types";

interface ChatMessagesProps {
  messages: ChatMessage[];
  phase: GenerationPhase;
  isGenerating: boolean;
  editingId: string | null;
  editText: string;
  onEditStart: (message: ChatMessage) => void;
  onEditChange: (text: string) => void;
  onEditCancel: () => void;
  onEditSave: () => void;
  onRegenerate: (id: string) => void;
  onStop: () => void;
}

function safeSourceUrl(source: SearchResult): string | null {
  try {
    const url = new URL(source.url);
    return url.protocol === "https:" || url.protocol === "http:" ? url.toString() : null;
  } catch { return null; }
}

function SourceList({ sources }: { sources: SearchResult[] }) {
  return (
    <section className="mt-6 border-t border-[var(--border)] pt-4" aria-label="Web search sources">
      <div className="mb-3 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.1em] text-[var(--muted)]"><Globe2 className="h-3.5 w-3.5" /> Sources <span className="rounded-full bg-[var(--soft-bg)] px-1.5 py-0.5 text-[10px] leading-none">{sources.length}</span></div>
      <div className="grid gap-2 sm:grid-cols-2">
        {sources.map((source, index) => {
          const href = safeSourceUrl(source);
          if (!href) return null;
          return (
            <a key={`${source.url}-${index}`} href={href} target="_blank" rel="noopener noreferrer" className="group/source flex min-w-0 items-center gap-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-3 py-2.5 transition-all hover:border-[var(--accent)]/35 hover:bg-[var(--accent-soft)]">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-[var(--soft-bg)] text-[10px] font-semibold text-[var(--accent)]">{index + 1}</span>
              <span className="min-w-0 flex-1"><span className="block truncate text-xs font-medium text-[var(--fg)]">{source.title}</span><span className="mt-0.5 block truncate text-[10px] text-[var(--muted)]">{source.domain}</span></span>
              <ExternalLink className="h-3 w-3 shrink-0 text-[var(--muted)] opacity-0 transition-opacity group-hover/source:opacity-100" />
            </a>
          );
        })}
      </div>
    </section>
  );
}

function LoadingAnswer({ phase }: { phase: GenerationPhase }) {
  return (
    <div className="py-1" role="status" aria-live="polite">
      <div className="mb-4 flex items-center gap-2 text-xs font-medium text-[var(--accent)]">
        {phase === "searching" ? <Globe2 className="h-3.5 w-3.5 animate-pulse" /> : <span className="thinking-dots"><i /><i /><i /></span>}
        {phase === "searching" ? "Searching the web..." : "Thinking..."}
      </div>
      <div className="space-y-2.5"><div className="skeleton-line h-3 w-[85%] rounded-full" /><div className="skeleton-line h-3 w-[69%] rounded-full" /><div className="skeleton-line h-3 w-[47%] rounded-full" /></div>
    </div>
  );
}

export function ChatMessages({ messages, phase, isGenerating, editingId, editText, onEditStart, onEditChange, onEditCancel, onEditSave, onRegenerate, onStop }: ChatMessagesProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  async function copyMessage(message: ChatMessage) {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopiedId(message.id);
      window.setTimeout(() => setCopiedId((id) => id === message.id ? null : id), 2000);
    } catch { toast.error("Could not copy to clipboard."); }
  }

  return (
    <div className="mx-auto w-full max-w-[820px] space-y-9 px-5 pb-8 pt-8 sm:px-8 sm:pt-10">
      {messages.map((message) => message.role === "user" ? (
        <article key={message.id} className="flex flex-row-reverse items-start gap-3 sm:gap-4" aria-label="Your message">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[var(--user-avatar)] text-[var(--user-avatar-fg)]"><UserRound className="h-4 w-4" strokeWidth={1.8} /></div>
          <div className="flex min-w-0 max-w-[calc(100%-48px)] flex-col items-end">
            <div className="mb-2 flex items-center gap-2 text-xs"><span className="font-semibold text-[var(--fg)]">You</span><time className="text-[11px] text-[var(--muted)]" dateTime={message.createdAt}>{formatMessageTime(message.createdAt)}</time></div>
            {editingId === message.id ? (
              <div className="w-[min(600px,calc(100vw-100px))] rounded-2xl border border-[var(--accent)] bg-[var(--surface)] p-3 shadow-sm">
                <textarea autoFocus value={editText} onChange={(event) => onEditChange(event.target.value)} aria-label="Edit your message" rows={4} className="min-h-24 w-full resize-y bg-transparent text-sm leading-relaxed text-[var(--fg)] outline-none" />
                <div className="mt-2 flex justify-end gap-2"><Button size="sm" variant="ghost" onClick={onEditCancel}>Cancel</Button><Button size="sm" disabled={!editText.trim()} onClick={onEditSave}>Save & resend</Button></div>
              </div>
            ) : (
              <div className="max-w-full whitespace-pre-wrap break-words rounded-[18px] rounded-tr-[5px] bg-[var(--user-bubble)] px-4 py-3 text-[14px] leading-[1.7] text-[var(--fg)]">{message.content}</div>
            )}
            {editingId !== message.id && <div className="mt-1.5 flex items-center gap-0.5 opacity-60 transition-opacity hover:opacity-100 focus-within:opacity-100">
              <button type="button" onClick={() => copyMessage(message)} aria-label="Copy message" title="Copy message" className="message-action">{copiedId === message.id ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}</button>
              <button type="button" onClick={() => onEditStart(message)} disabled={isGenerating} aria-label="Edit message" title="Edit and resend" className="message-action"><Pencil className="h-3.5 w-3.5" /></button>
            </div>}
          </div>
        </article>
      ) : (
        <article key={message.id} className="flex items-start gap-3 sm:gap-4" aria-label="Assistant response">
          <BrandMark size="sm" className="!rounded-full" />
          <div className="min-w-0 flex-1">
            <div className="mb-2.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs"><span className="font-semibold text-[var(--fg)]">Aster</span><time className="text-[11px] text-[var(--muted)]" dateTime={message.createdAt}>{formatMessageTime(message.createdAt)}</time>{message.modelId && <span className="max-w-[170px] truncate rounded-md bg-[var(--soft-bg)] px-1.5 py-0.5 text-[10px] text-[var(--muted)]" title={`${message.providerName || "Provider"} · ${message.modelId}`}>{message.modelId}</span>}{message.usedWebSearch && <span className="inline-flex items-center gap-1 text-[10px] text-[var(--accent)]"><Globe2 className="h-3 w-3" /> Web search</span>}</div>

            {message.content ? <><MarkdownContent content={message.content} />{message.status === "streaming" && phase === "writing" && <span className="stream-cursor ml-0.5 inline-block h-4 w-[3px] translate-y-0.5 rounded-full bg-[var(--accent)]" aria-hidden="true" />}</> : message.status === "streaming" ? <LoadingAnswer phase={phase} /> : null}

            {message.error && <div role="alert" className="mt-3 flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 p-3 text-xs leading-relaxed text-red-700 dark:border-red-900 dark:bg-red-950/30 dark:text-red-300"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><span>{message.error}</span></div>}
            {message.status === "stopped" && <p className="mt-2 text-xs italic text-[var(--muted)]">Response stopped</p>}
            {message.usedWebSearch && message.status !== "streaming" && message.citations?.length === 0 && <p className="mt-3 flex items-center gap-1.5 text-xs text-[var(--muted)]"><Globe2 className="h-3.5 w-3.5" /> No web results were found for this query.</p>}
            {message.citations && message.citations.length > 0 && <SourceList sources={message.citations} />}

            <div className="mt-3 flex items-center gap-0.5 opacity-70 transition-opacity hover:opacity-100 focus-within:opacity-100">
              {message.content && <button type="button" onClick={() => copyMessage(message)} aria-label="Copy response" title="Copy response" className="message-action">{copiedId === message.id ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}</button>}
              {message.status === "streaming" ? <button type="button" onClick={onStop} aria-label="Stop generating" title="Stop generating" className="message-action"><Square className="h-3.5 w-3.5" /></button> : <button type="button" onClick={() => onRegenerate(message.id)} disabled={isGenerating} aria-label="Regenerate response" title="Regenerate response" className="message-action"><RotateCcw className="h-3.5 w-3.5" /></button>}
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}
