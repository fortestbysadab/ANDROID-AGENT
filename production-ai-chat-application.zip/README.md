# Aster — AI chat workspace

A production-oriented, bring-your-own-key chat client built with Next.js App Router, React, TypeScript, Tailwind CSS v4, and shadcn-style Radix UI components. **There are no seeded providers, models, search results, or assistant replies.** Every model list, search result, and answer comes from a configured API.

## Get started

1. Install dependencies with `npm install` and run `npm run dev`.
2. Open the app, choose **Connections → Add provider**, and enter a name, an OpenAI-compatible API base URL, and an API key. The URL should be the API root, usually ending in `/v1` (not `/models`). For example, OpenAI uses `https://api.openai.com/v1`, OpenRouter uses `https://openrouter.ai/api/v1`, and Groq uses `https://api.groq.com/openai/v1`.
3. Select **Save & fetch models**. Aster calls that provider's actual `GET /models` endpoint and fills the model picker with the returned models. Choose a model and send a message.
4. Optional: add a Brave Search, Tavily, or SerpAPI key to the connection, then turn on **Web search** beside the message box.

The included `/api/health` endpoint uses the template's PostgreSQL connection (`DATABASE_URL` in `.env`). Chat data does **not** require a database; it is deliberately kept on the user's device. Deploy with a working database if you need the provided health check to pass.

## Project structure

- `src/app/page.tsx` — application entry point.
- `src/app/globals.css` — Tailwind import, theme tokens, Markdown/code styling, and animations.
- `src/app/api/models/route.ts` — server-side proxy for real OpenAI-compatible model discovery.
- `src/app/api/chat/route.ts` — streaming chat completions proxy; adds grounded search context when requested.
- `src/app/api/search/route.ts` — real Brave, Tavily, and SerpAPI search adapters.
- `src/lib/server/provider-utils.ts` — provider URL validation and upstream error handling.
- `src/lib/api-client.ts` — browser service layer, including the chunk-safe SSE reader.
- `src/lib/types.ts` — provider, model, conversation, message, and search result contracts.
- `src/lib/workspace.ts` — versioned local persistence and conversation helpers.
- `src/components/chat-workspace.tsx` — application state and request orchestration.
- `src/components/{chat-sidebar,chat-messages,chat-composer,model-picker,provider-settings}.tsx` — focused UI components.
- `src/components/ui/` — reusable shadcn-style Button, Dialog, and Select primitives.

## How it works

**Providers:** Each saved provider has its own URL, key, discovered models, optional search service, and optional search key. Saving automatically fetches `/models`; use the refresh button to fetch them again. The picker groups actual model IDs by provider. A `/models` response can contain non-chat models; if one cannot use `/chat/completions`, select a different model.

**Chat:** `POST /api/chat` passes the selected model and conversation to the provider's `/chat/completions` with `stream: true`. The response body is forwarded without buffering. The browser decodes OpenAI-style server-sent events via `fetch` and `ReadableStream`. Stop aborts the request. Edit-and-resend and regenerate create a new branch from that point, removing later messages in that conversation. Conversations, settings, theme, and model choice persist locally.

**Search:** When enabled, Aster first calls the configured search API, shows the search state, attaches real sources to the assistant response, and passes numbered result excerpts into the chat context. The model is asked to cite URLs in its answer. Results are reference excerpts, not claims that the app read entire pages. Search failures are shown instead of silently inventing sources.

**Keys and security:** API keys are stored in browser `localStorage` to meet the bring-your-own-key workflow. They are sent to this app's same-origin server routes only for the duration of a request, and are not saved in the database or server environment. Anyone with access to this browser profile or its JavaScript environment may be able to read local storage; avoid shared devices. In production, provider proxy URLs require HTTPS and reject localhost/IP hosts as well as hostnames resolving to private or reserved addresses. Deploy behind appropriate outbound network controls as additional protection against DNS rebinding. Only connect to providers you trust.

## Extending providers and search

Any service exposing OpenAI-compatible `GET /models` and `POST /chat/completions` works without code changes: just add its API root in Connections. To add another web search service, extend the `SearchEngine` union in `src/lib/types.ts`, add a branch in `src/app/api/search/route.ts` that normalizes results to `SearchResult`, and add an option in `src/components/provider-settings.tsx`. No fabricated fallback results are used.

## Validation

Run `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, and `npm run build`. Live model discovery, search, and chat require real user-supplied credentials and a reachable provider.
