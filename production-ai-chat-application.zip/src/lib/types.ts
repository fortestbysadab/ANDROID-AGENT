export type SearchEngine = "brave" | "tavily" | "serpapi";
export type ThemePreference = "light" | "dark" | "system";

export interface ModelInfo {
  id: string;
  name?: string;
  ownedBy?: string;
}

export interface ProviderConfig {
  id: string;
  name: string;
  /** The OpenAI-compatible API root, usually ending in /v1. */
  baseUrl: string;
  apiKey: string;
  searchEngine: SearchEngine;
  searchApiKey: string;
  models: ModelInfo[];
  lastFetchedAt?: string;
  modelError?: string;
}

export type ProviderDraft = Pick<
  ProviderConfig,
  "id" | "name" | "baseUrl" | "apiKey" | "searchEngine" | "searchApiKey"
>;

export interface ModelSelection {
  providerId: string;
  modelId: string;
}

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  domain: string;
}

export type MessageStatus = "streaming" | "complete" | "stopped" | "error";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
  status: MessageStatus;
  modelId?: string;
  providerName?: string;
  citations?: SearchResult[];
  searchQuery?: string;
  usedWebSearch?: boolean;
  error?: string;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: ChatMessage[];
}

export interface WorkspaceState {
  providers: ProviderConfig[];
  selectedModel: ModelSelection | null;
  conversations: Conversation[];
  activeConversationId: string | null;
  webSearchEnabled: boolean;
  theme: ThemePreference;
}

export type GenerationPhase = "idle" | "searching" | "writing";
