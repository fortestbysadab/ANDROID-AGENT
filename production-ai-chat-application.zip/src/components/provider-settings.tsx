"use client";

import { useState, type FormEvent } from "react";
import { AlertCircle, ArrowLeft, ArrowUpRight, Check, Cloud, Eye, EyeOff, KeyRound, LockKeyhole, Plus, RefreshCw, Server, Trash2, Webhook } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { ProviderConfig, ProviderDraft, SearchEngine } from "@/lib/types";

const presets = [
  { name: "OpenAI", baseUrl: "https://api.openai.com/v1" },
  { name: "OpenRouter", baseUrl: "https://openrouter.ai/api/v1" },
  { name: "Groq", baseUrl: "https://api.groq.com/openai/v1" },
];

interface ProviderSettingsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  providers: ProviderConfig[];
  onSave: (draft: ProviderDraft) => Promise<{ ok: boolean; error?: string }>;
  onRefresh: (provider: ProviderConfig) => Promise<void>;
  onDelete: (id: string) => void;
}

function newDraft(): ProviderDraft {
  return { id: crypto.randomUUID(), name: "", baseUrl: "", apiKey: "", searchEngine: "brave", searchApiKey: "" };
}

export function ProviderSettings({ open, onOpenChange, providers, onSave, onRefresh, onDelete }: ProviderSettingsProps) {
  const [draft, setDraft] = useState<ProviderDraft | null>(null);
  const [saving, setSaving] = useState(false);
  const [refreshingId, setRefreshingId] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [showKeys, setShowKeys] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  function updateDraft(changes: Partial<ProviderDraft>) {
    setDraft((previous) => previous ? { ...previous, ...changes } : previous);
    setFormError(null);
  }

  function closeSettings(next: boolean) {
    if (!next) { setDraft(null); setPendingDelete(null); setFormError(null); }
    onOpenChange(next);
  }

  async function handleSave(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!draft) return;
    if (!draft.name.trim() || !draft.baseUrl.trim()) {
      setFormError("A name and API base URL are required.");
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      const result = await onSave({
        ...draft,
        name: draft.name.trim(),
        baseUrl: draft.baseUrl.trim().replace(/\/+$/, ""),
        apiKey: draft.apiKey.trim(),
        searchApiKey: draft.searchApiKey.trim(),
      });
      if (result.ok) setDraft(null);
      else setFormError(result.error || "Could not load models. Your connection was saved; check the details and try again.");
    } catch {
      setFormError("Could not save this connection. Please try again.");
    } finally { setSaving(false); }
  }

  async function handleRefresh(provider: ProviderConfig) {
    setRefreshingId(provider.id);
    try { await onRefresh(provider); }
    finally { setRefreshingId(null); }
  }

  return (
    <Dialog open={open} onOpenChange={closeSettings}>
      <DialogContent side="right" className="p-0" aria-describedby="settings-description">
        <div className="shrink-0 border-b border-[var(--border)] px-7 pb-5 pt-7">
          <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--accent-soft)] text-[var(--accent)]"><Webhook className="h-5 w-5" /></div>
          <DialogTitle className="text-[23px] font-semibold tracking-[-0.035em]">Connections</DialogTitle>
          <DialogDescription id="settings-description" className="mt-1">Bring your own API keys. Connect any OpenAI-compatible provider.</DialogDescription>
        </div>

        <div className="custom-scrollbar min-h-0 flex-1 overflow-y-auto px-7 py-6">
          {draft ? (
            <div className="pb-8">
              <button type="button" onClick={() => { setDraft(null); setFormError(null); }} className="mb-6 flex items-center gap-1.5 text-xs font-medium text-[var(--muted)] hover:text-[var(--fg)]">
                <ArrowLeft className="h-3.5 w-3.5" /> All connections
              </button>
              <h3 className="text-lg font-semibold tracking-tight">{providers.some((p) => p.id === draft.id) ? "Edit connection" : "Add a provider"}</h3>
              <p className="mt-1 text-sm text-[var(--muted)]">Models are fetched automatically when you save.</p>

              <form onSubmit={handleSave} className="mt-7 space-y-5">
                <div>
                  <label htmlFor="provider-name" className="field-label">Provider name <span className="text-[var(--accent)]">*</span></label>
                  <input id="provider-name" className="field-input" value={draft.name} onChange={(e) => updateDraft({ name: e.target.value })} placeholder="e.g. OpenAI, Groq, or My API" required maxLength={60} autoComplete="off" />
                </div>
                <div>
                  <label htmlFor="provider-url" className="field-label">API base URL <span className="text-[var(--accent)]">*</span></label>
                  <input id="provider-url" className="field-input font-mono text-[13px]" type="url" value={draft.baseUrl} onChange={(e) => updateDraft({ baseUrl: e.target.value })} placeholder="https://api.example.com/v1" required maxLength={2048} spellCheck={false} autoComplete="url" />
                  <p className="mt-2 text-xs leading-relaxed text-[var(--muted)]">Use the API root, not the full /models URL. We call /models and /chat/completions for you.</p>
                  <div className="mt-3 flex flex-wrap items-center gap-1.5">
                    <span className="mr-1 text-[11px] text-[var(--muted)]">Quick fill</span>
                    {presets.map((preset) => (
                      <button type="button" key={preset.name} onClick={() => updateDraft({ name: preset.name, baseUrl: preset.baseUrl })} className="rounded-md border border-[var(--border)] bg-[var(--surface)] px-2 py-1 text-[11px] font-medium text-[var(--muted)] transition-colors hover:border-[var(--accent)] hover:text-[var(--accent)]">{preset.name}</button>
                    ))}
                  </div>
                </div>
                <div>
                  <label htmlFor="provider-key" className="field-label">API key <span className="font-normal text-[var(--muted)]">(optional for local APIs)</span></label>
                  <div className="relative">
                    <input id="provider-key" className="field-input pr-11 font-mono text-[13px]" type={showKeys ? "text" : "password"} value={draft.apiKey} onChange={(e) => updateDraft({ apiKey: e.target.value })} placeholder="sk-..." maxLength={2000} autoComplete="off" spellCheck={false} />
                    <button type="button" onClick={() => setShowKeys((value) => !value)} className="absolute inset-y-0 right-2 flex w-9 items-center justify-center text-[var(--muted)] hover:text-[var(--fg)]" aria-label={showKeys ? "Hide API keys" : "Show API keys"}>
                      {showKeys ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="border-t border-[var(--border)] pt-5">
                  <div className="mb-4 flex items-center gap-2"><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[var(--soft-bg)] text-[var(--muted)]"><Cloud className="h-4 w-4" /></span><div><h4 className="text-sm font-semibold">Web search <span className="font-normal text-[var(--muted)]">· optional</span></h4><p className="text-[11px] text-[var(--muted)]">Give this provider access to live sources.</p></div></div>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="search-engine" className="field-label">Search service</label>
                      <Select value={draft.searchEngine} onValueChange={(value) => updateDraft({ searchEngine: value as SearchEngine })}>
                        <SelectTrigger id="search-engine" className="h-11"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="brave">Brave Search</SelectItem>
                          <SelectItem value="tavily">Tavily</SelectItem>
                          <SelectItem value="serpapi">SerpAPI (Google)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label htmlFor="search-key" className="field-label">Web search API key</label>
                      <div className="relative">
                        <input id="search-key" className="field-input pr-11 font-mono text-[13px]" type={showKeys ? "text" : "password"} value={draft.searchApiKey} onChange={(e) => updateDraft({ searchApiKey: e.target.value })} placeholder="Add a key to enable web search" maxLength={2000} autoComplete="off" spellCheck={false} />
                        <KeyRound className="pointer-events-none absolute right-4 top-3.5 h-4 w-4 text-[var(--muted)]" />
                      </div>
                    </div>
                  </div>
                </div>

                {formError && <div role="alert" className="flex gap-2 rounded-xl border border-red-200 bg-red-50 p-3 text-xs leading-relaxed text-red-700 dark:border-red-900 dark:bg-red-950/30 dark:text-red-300"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />{formError}</div>}
                <div className="flex gap-2 pt-2">
                  <Button type="submit" disabled={saving} className="flex-1">
                    {saving ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                    {saving ? "Fetching models..." : "Save & fetch models"}
                  </Button>
                  <Button variant="outline" onClick={() => setDraft(null)}>Cancel</Button>
                </div>
              </form>
            </div>
          ) : (
            <div>
              <div className="mb-5 flex items-center justify-between">
                <div><h3 className="text-sm font-semibold">Your providers</h3><p className="mt-0.5 text-xs text-[var(--muted)]">{providers.length} connected {providers.length === 1 ? "provider" : "providers"}</p></div>
                <Button size="sm" onClick={() => { setDraft(newDraft()); setShowKeys(false); }}><Plus className="h-3.5 w-3.5" /> Add provider</Button>
              </div>

              {providers.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-[var(--border-strong)] bg-[var(--soft-bg)] px-5 py-9 text-center">
                  <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--surface)] text-[var(--accent)] shadow-sm"><Server className="h-5 w-5" /></div>
                  <h4 className="text-sm font-semibold">No providers yet</h4>
                  <p className="mx-auto mt-2 max-w-[260px] text-xs leading-relaxed text-[var(--muted)]">Connect an API to automatically discover its available models and start chatting.</p>
                  <Button variant="outline" size="sm" className="mt-5" onClick={() => setDraft(newDraft())}>Set up your first provider <ArrowUpRight className="h-3.5 w-3.5" /></Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {providers.map((provider) => (
                    <div key={provider.id} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 shadow-[0_2px_12px_rgba(20,20,30,0.025)]">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex min-w-0 items-start gap-3">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[var(--accent-soft)] text-sm font-bold text-[var(--accent)]">{provider.name.slice(0, 1).toUpperCase()}</div>
                          <div className="min-w-0"><h4 className="truncate text-sm font-semibold">{provider.name}</h4><p className="mt-0.5 truncate text-[11px] text-[var(--muted)]">{provider.baseUrl}</p></div>
                        </div>
                        <span className={`mt-1 h-2 w-2 shrink-0 rounded-full ${provider.modelError ? "bg-amber-500" : provider.models.length ? "bg-emerald-500" : "bg-[var(--muted)]"}`} title={provider.modelError ? "Model fetch failed" : "Connection saved"} />
                      </div>
                      <div className="mt-4 flex items-center justify-between border-t border-[var(--border)] pt-3">
                        <span className="text-xs text-[var(--muted)]">{provider.modelError ? "Models unavailable" : `${provider.models.length} ${provider.models.length === 1 ? "model" : "models"} available`}{provider.searchApiKey ? "  ·  Search ready" : ""}</span>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon-sm" aria-label={`Refresh models for ${provider.name}`} title="Refresh models" onClick={() => handleRefresh(provider)} disabled={refreshingId === provider.id}><RefreshCw className={`h-3.5 w-3.5 ${refreshingId === provider.id ? "animate-spin" : ""}`} /></Button>
                          <Button variant="ghost" size="sm" onClick={() => { setDraft({ id: provider.id, name: provider.name, baseUrl: provider.baseUrl, apiKey: provider.apiKey, searchEngine: provider.searchEngine, searchApiKey: provider.searchApiKey }); setFormError(null); }}>Edit</Button>
                          <Button variant="ghost" size="icon-sm" aria-label={`Remove ${provider.name}`} title="Remove provider" onClick={() => setPendingDelete(provider.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                        </div>
                      </div>
                      {provider.modelError && <p className="mt-2 rounded-lg bg-amber-50 px-2.5 py-2 text-[11px] leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300">{provider.modelError}</p>}
                      {pendingDelete === provider.id && <div className="mt-3 flex items-center justify-between gap-2 rounded-lg bg-red-50 px-3 py-2 dark:bg-red-950/30"><span className="text-xs text-red-700 dark:text-red-300">Remove this connection?</span><div className="flex gap-2"><button type="button" onClick={() => setPendingDelete(null)} className="text-xs text-[var(--muted)]">Cancel</button><button type="button" onClick={() => { onDelete(provider.id); setPendingDelete(null); }} className="text-xs font-semibold text-red-600">Remove</button></div></div>}
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-7 rounded-xl bg-[var(--soft-bg)] p-4">
                <div className="flex gap-3"><LockKeyhole className="mt-0.5 h-4 w-4 shrink-0 text-[var(--muted)]" /><div><p className="text-xs font-semibold">Your keys, your control</p><p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">Keys and chats are stored in this browser&apos;s local storage. Requests pass through this app&apos;s server, but credentials are never saved there. Avoid using shared devices.</p></div></div>
              </div>
            </div>
          )}
        </div>
        <div className="shrink-0 border-t border-[var(--border)] px-7 py-4 text-center text-[11px] text-[var(--muted)]">Compatible with OpenAI-style /models and /chat/completions APIs</div>
      </DialogContent>
    </Dialog>
  );
}
