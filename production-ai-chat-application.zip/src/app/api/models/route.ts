import type { ModelInfo } from "@/lib/types";
import { cleanKey, providerEndpoint, RouteError, routeErrorResponse, upstreamFailure } from "@/lib/server/provider-utils";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== "object") throw new RouteError("Invalid request body.");
    const input = body as Record<string, unknown>;
    const url = await providerEndpoint(input.baseUrl, "models");
    const apiKey = cleanKey(input.apiKey);

    const response = await fetch(url, {
      headers: {
        Accept: "application/json",
        ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
      },
      cache: "no-store",
      signal: AbortSignal.any([request.signal, AbortSignal.timeout(20_000)]),
    });
    if (!response.ok) throw await upstreamFailure(response, "Provider");

    const payload: unknown = await response.json();
    if (!payload || typeof payload !== "object" || !Array.isArray((payload as { data?: unknown }).data)) {
      throw new RouteError("The provider returned an invalid /models response (expected a data array).", 502);
    }
    const models: ModelInfo[] = (payload as { data: unknown[] }).data.flatMap((item): ModelInfo[] => {
      if (!item || typeof item !== "object" || typeof (item as { id?: unknown }).id !== "string") return [];
      const model = item as Record<string, unknown>;
      return [{
        id: model.id as string,
        name: typeof model.name === "string" ? model.name : undefined,
        ownedBy: typeof model.owned_by === "string" ? model.owned_by : undefined,
      }];
    }).sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));

    return Response.json({ models }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return routeErrorResponse(error, "Could not load models from this provider. Check the URL and try again.");
  }
}
