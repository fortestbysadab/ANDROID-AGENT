"use client";

import { Children, isValidElement, useState, type ComponentProps, type ReactNode } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import { Check, Copy } from "lucide-react";
import { toast } from "sonner";

function plainText(node: ReactNode): string {
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(plainText).join("");
  if (isValidElement(node)) return plainText((node.props as { children?: ReactNode }).children);
  return "";
}

function CodeBlock({ children, ...props }: ComponentProps<"pre">) {
  const [copied, setCopied] = useState(false);
  const child = Children.toArray(children).find(isValidElement) as React.ReactElement<{ className?: string }> | undefined;
  const language = child?.props.className?.match(/language-([\w+#.-]+)/)?.[1] || "code";
  const code = plainText(children).replace(/\n$/, "");

  async function copyCode() {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch { toast.error("Could not copy to clipboard."); }
  }

  return (
    <div className="code-window">
      <div className="code-window-header">
        <span className="font-mono text-[11px] font-medium text-[#a6aab9]">{language}</span>
        <button type="button" onClick={copyCode} className="flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium text-[#a6aab9] transition-colors hover:bg-white/10 hover:text-white" aria-label="Copy code block">
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
          {copied ? "Copied" : "Copy code"}
        </button>
      </div>
      <pre {...props} className="overflow-x-auto px-4 pb-4 pt-2 text-[13px] leading-6 text-[#e5e7ef]">{children}</pre>
    </div>
  );
}

export function MarkdownContent({ content }: { content: string }) {
  return (
    <div className="markdown-body min-w-0 break-words text-[14px] leading-[1.8] sm:text-[15px]">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[rehypeHighlight]}
        components={{
          pre: CodeBlock,
          a: ({ href, children, ...props }) => (
            <a href={href} target="_blank" rel="noopener noreferrer" {...props}>{children}</a>
          ),
          table: ({ children, ...props }) => (
            <div className="my-4 w-full overflow-x-auto rounded-xl border border-[var(--border)]">
              <table {...props}>{children}</table>
            </div>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
