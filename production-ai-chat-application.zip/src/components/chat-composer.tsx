"use client";

import { useEffect, type KeyboardEvent, type RefObject } from "react";
import { ArrowUp, Globe2, LockKeyhole, Square } from "lucide-react";
import { cn } from "@/lib/utils";

interface ChatComposerProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  onStop: () => void;
  onToggleSearch: () => void;
  webSearchEnabled: boolean;
  isGenerating: boolean;
  hasModel: boolean;
  inputRef: RefObject<HTMLTextAreaElement | null>;
}

export function ChatComposer({ value, onChange, onSend, onStop, onToggleSearch, webSearchEnabled, isGenerating, hasModel, inputRef }: ChatComposerProps) {
  useEffect(() => {
    const input = inputRef.current;
    if (!input) return;
    input.style.height = "auto";
    input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
  }, [value, inputRef]);

  function handleKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
      event.preventDefault();
      if (!isGenerating && value.trim()) onSend();
    }
  }

  return (
    <div className="mx-auto w-full max-w-[820px] px-4 pb-3 pt-3 sm:px-8 sm:pb-5">
      <div className="composer-shell rounded-[20px] border border-[var(--composer-border)] bg-[var(--surface)] p-2 shadow-[0_8px_35px_rgba(28,30,52,0.09),0_2px_6px_rgba(28,30,52,0.04)] transition-[border-color,box-shadow] focus-within:border-[var(--accent)]/50 focus-within:shadow-[0_8px_38px_rgba(91,72,202,0.11)]">
        <label htmlFor="chat-input" className="sr-only">Message</label>
        <textarea
          id="chat-input"
          ref={inputRef}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={hasModel ? "Message Aster..." : "Connect a provider to start chatting..."}
          rows={1}
          aria-label="Message Aster"
          className="custom-scrollbar block max-h-[180px] min-h-[56px] w-full resize-none overflow-y-auto bg-transparent px-3 pb-2 pt-3 text-[14px] leading-6 text-[var(--fg)] outline-none placeholder:text-[var(--placeholder)] sm:text-[15px]"
        />
        <div className="flex items-center justify-between gap-2 px-1 pb-0.5">
          <button
            type="button"
            onClick={onToggleSearch}
            aria-label={webSearchEnabled ? "Disable web search" : "Enable web search"}
            aria-pressed={webSearchEnabled}
            className={cn("inline-flex h-8 items-center gap-1.5 rounded-lg border px-2.5 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)]", webSearchEnabled ? "border-[var(--accent)]/25 bg-[var(--accent-soft)] text-[var(--accent)]" : "border-transparent text-[var(--muted)] hover:bg-[var(--hover-bg)] hover:text-[var(--fg)]")}
          ><Globe2 className="h-4 w-4" /><span>Web search</span>{webSearchEnabled && <span className="ml-0.5 h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />}</button>
          <div className="flex items-center gap-3">
            <span className="hidden text-[11px] text-[var(--muted)] sm:inline">{isGenerating ? "Generating response" : "Enter to send · Shift + Enter for new line"}</span>
            <button
              type="button"
              onClick={isGenerating ? onStop : onSend}
              disabled={!isGenerating && !value.trim()}
              aria-label={isGenerating ? "Stop generation" : "Send message"}
              title={isGenerating ? "Stop generation" : "Send message"}
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] bg-[var(--accent)] text-white shadow-[0_3px_10px_rgba(100,80,205,0.24)] transition-all hover:-translate-y-0.5 hover:bg-[var(--accent-hover)] disabled:cursor-not-allowed disabled:bg-[var(--disabled-bg)] disabled:text-[var(--muted)] disabled:shadow-none disabled:hover:translate-y-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)] focus-visible:ring-offset-2"
            >{isGenerating ? <Square className="h-3.5 w-3.5 fill-current" /> : <ArrowUp className="h-[17px] w-[17px]" strokeWidth={2.3} />}</button>
          </div>
        </div>
      </div>
      <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-[10px] leading-relaxed text-[var(--muted)] sm:text-[11px]"><LockKeyhole className="h-3 w-3" /> Your chats stay on this device. AI can make mistakes — verify important details.</p>
    </div>
  );
}
