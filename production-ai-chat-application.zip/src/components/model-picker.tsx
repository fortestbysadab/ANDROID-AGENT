"use client";

import { Bot, ChevronDown, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectSeparator, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { ModelSelection, ProviderConfig } from "@/lib/types";

interface ModelPickerProps {
  providers: ProviderConfig[];
  selectedModel: ModelSelection | null;
  onChange: (selection: ModelSelection) => void;
  onOpenSettings: () => void;
}

function selectionValue(selection: ModelSelection) {
  return `${selection.providerId}::${selection.modelId}`;
}

export function ModelPicker({ providers, selectedModel, onChange, onOpenSettings }: ModelPickerProps) {
  const available = providers.filter((provider) => provider.models.length > 0);
  if (!available.length) {
    return <Button variant="outline" size="sm" className="h-9 max-w-[220px] gap-2 border-[var(--border)] px-3 text-[var(--muted)]" onClick={onOpenSettings}><Plus className="h-3.5 w-3.5" /> {providers.length ? "Manage providers" : "Connect a provider"} <ChevronDown className="h-3.5 w-3.5" /></Button>;
  }

  return (
    <Select
      value={selectedModel ? selectionValue(selectedModel) : undefined}
      onValueChange={(value) => {
        for (const provider of available) {
          const model = provider.models.find((item) => selectionValue({ providerId: provider.id, modelId: item.id }) === value);
          if (model) { onChange({ providerId: provider.id, modelId: model.id }); return; }
        }
      }}
    >
      <SelectTrigger aria-label="Select AI model" className="h-9 w-[min(250px,50vw)] gap-2 rounded-lg border-[var(--border)] bg-[var(--surface)] px-2.5 text-xs font-medium shadow-none sm:w-[250px]">
        <Bot className="h-4 w-4 shrink-0 text-[var(--accent)]" />
        <SelectValue placeholder="Select a model" />
      </SelectTrigger>
      <SelectContent className="w-[min(360px,calc(100vw-2rem))]">
        <div className="px-3 pb-1 pt-2 text-xs font-semibold">Available models</div>
        {available.map((provider, index) => (
          <SelectGroup key={provider.id}>
            {index > 0 && <SelectSeparator />}
            <SelectLabel>{provider.name} <span className="ml-1 font-normal normal-case tracking-normal">({provider.models.length})</span></SelectLabel>
            {provider.models.map((model) => (
              <SelectItem key={`${provider.id}-${model.id}`} value={selectionValue({ providerId: provider.id, modelId: model.id })} title={model.id}>
                <span className="block max-w-[290px] truncate">{model.name || model.id}</span>
              </SelectItem>
            ))}
          </SelectGroup>
        ))}
      </SelectContent>
    </Select>
  );
}
