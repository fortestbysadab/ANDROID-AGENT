import type { SearchEngine, SearchResult } from "@/lib/types";
import { cleanKey, RouteError, routeErrorResponse, upstreamFailure } from "@/lib/server/provider-utils";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type SearchItem = Record<string, unknown>;

function normaliseResults(items: unknown, engine: SearchEngine): SearchResult[] {
  if (!Array.isArray(items)) return [];
  return items.flatMap((value): SearchResult[] => {
    if (!value || typeof value !== "object") return [];
    const item = value as SearchItem;
    const title = typeof item.title === "string" ? item.title : "";
    const link = engine === "serpapi" ? item.link : item.url;
    if (!title || typeof link !== "string") return [];
    let url: URL;
    try { url = new URL(link); } catch { return []; }
    if (url.protocol !== "https:" && url.protocol !== "http:") return [];
    const rawSnippet = engine === "tavily" ? item.content : engine === "serpapi" ? item.snippet : item.description;
    const snippet = typeof rawSnippet === "string"
      ? rawSnippet.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim().slice(0, 600)
      : "";
    return [{ title: title.slice(0, 240), url: url.toString(), snippet, domain: url.hostname.replace(/^www\./, "") }];
  }).slice(0, 5);
}

export async function POST(request: Request) {
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== "object") throw new RouteError("Invalid search request.");
    const input = body as Record<string, unknown>;
    const query = typeof input.query === "string" ? input.query.trim() : "";
    if (!query || query.length > 500) throw new RouteError("Enter a search query under 500 characters.");
    const engine = input.engine;
    if (engine !== "brave" && engine !== "tavily" && engine !== "serpapi") {
      throw new RouteError("Choose Brave, Tavily, or SerpAPI as your search provider.");
    }
    const key = cleanKey(input.apiKey, true);
    const signal = AbortSignal.any([request.signal, AbortSignal.timeout(25_000)]);
    let response: Response;
    let items: unknown;

    if (engine === "brave") {
      const url = new URL("https://api.search.brave.com/res/v1/web/search");
      url.searchParams.set("q", query);
      url.searchParams.set("count", "5");
      response = await fetch(url, {
        headers: { Accept: "application/json", "X-Subscription-Token": key },
        cache: "no-store", signal,
      });
      if (!response.ok) throw await upstreamFailure(response, "Brave Search");
      const data = await response.json();
      items = data.web?.results;
    } else if (engine === "tavily") {
      response = await fetch("https://api.tavily.com/search", {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({ query, search_depth: "basic", max_results: 5, include_answer: false, include_raw_content: false }),
        cache: "no-store", signal,
      });
      if (!response.ok) throw await upstreamFailure(response, "Tavily");
      const data = await response.json();
      items = data.results;
    } else {
      const url = new URL("https://serpapi.com/search.json");
      url.searchParams.set("engine", "google");
      url.searchParams.set("q", query);
      url.searchParams.set("num", "5");
      url.searchParams.set("api_key", key);
      response = await fetch(url, { headers: { Accept: "application/json" }, cache: "no-store", signal });
      if (!response.ok) throw await upstreamFailure(response, "SerpAPI");
      const data = await response.json();
      if (typeof data.error === "string") throw new RouteError(`SerpAPI: ${data.error.slice(0, 300)}`, 502);
      items = data.organic_results;
    }

    return Response.json({ results: normaliseResults(items, engine) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return routeErrorResponse(error, "Web search failed. Check your search API key and try again.");
  }
}
