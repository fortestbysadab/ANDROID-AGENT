import { lookup } from "node:dns/promises";
import { isIP } from "node:net";

export class RouteError extends Error {
  constructor(message: string, public status = 400) {
    super(message);
    this.name = "RouteError";
  }
}

function isPrivateAddress(address: string): boolean {
  if (isIP(address) === 4) {
    const [a, b] = address.split(".").map(Number);
    return a === 0 || a === 10 || a === 127 ||
      (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && (b === 0 || b === 168)) ||
      (a === 198 && b >= 18 && b <= 19) || a >= 224;
  }
  const lower = address.toLowerCase();
  const mapped = lower.match(/::ffff:(\d+\.\d+\.\d+\.\d+)$/);
  if (mapped) return isPrivateAddress(mapped[1]);
  const first = Number.parseInt(lower.split(":")[0] || "0", 16);
  return lower === "::" || lower === "::1" || (first >= 0xfc00 && first <= 0xfdff) ||
    (first >= 0xfe80 && first <= 0xfebf) || (first >= 0xff00 && first <= 0xffff);
}

/** API roots are supplied by the user, so validate them before server-side fetches. */
export async function providerEndpoint(baseUrl: unknown, resource: "models" | "chat/completions"): Promise<string> {
  if (typeof baseUrl !== "string" || !baseUrl.trim() || baseUrl.length > 2048) {
    throw new RouteError("Enter a valid provider base URL.");
  }
  let url: URL;
  try { url = new URL(baseUrl.trim()); }
  catch { throw new RouteError("Enter a valid provider base URL, including https:// and the API path (usually /v1)."); }

  if (!(["https:", "http:"].includes(url.protocol)) || url.username || url.password || url.search || url.hash) {
    throw new RouteError("The provider URL must be an HTTP(S) API root without credentials, query parameters, or fragments.");
  }
  if (url.pathname.match(/\/(models|chat\/completions)\/?$/)) {
    throw new RouteError("Use the API base URL (usually ending in /v1), not a /models or /chat/completions endpoint.");
  }

  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (process.env.NODE_ENV === "production") {
    if (url.protocol !== "https:") throw new RouteError("Provider connections require HTTPS in production.");
    if (isIP(host) || host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal")) {
      throw new RouteError("Local and IP-address provider URLs are not allowed in production.");
    }
    try {
      const addresses = await lookup(host, { all: true });
      if (!addresses.length || addresses.some((entry) => isPrivateAddress(entry.address))) {
        throw new RouteError("The provider hostname resolves to a private or reserved address.");
      }
    } catch (error) {
      if (error instanceof RouteError) throw error;
      throw new RouteError("Could not resolve the provider hostname. Check the API URL.");
    }
  }
  return `${url.origin}${url.pathname.replace(/\/+$/, "")}/${resource}`;
}

export function cleanKey(value: unknown, required = false): string {
  if (typeof value !== "string" || value.length > 2000 || /[\r\n]/.test(value)) {
    throw new RouteError("Enter a valid API key.");
  }
  if (required && !value.trim()) throw new RouteError("A search API key is required for web search.");
  return value.trim();
}

export async function upstreamFailure(response: Response, service: string): Promise<RouteError> {
  let detail = "";
  try {
    const body: unknown = await response.json();
    if (body && typeof body === "object") {
      const record = body as Record<string, unknown>;
      if (typeof record.error === "string") detail = record.error;
      else if (record.error && typeof record.error === "object" && "message" in record.error && typeof record.error.message === "string") detail = record.error.message;
      else if (typeof record.message === "string") detail = record.message;
    }
  } catch { /* Avoid rendering arbitrary upstream HTML errors. */ }
  const label = response.status === 429 ? `${service} rate limit reached` : `${service} returned ${response.status}`;
  return new RouteError(detail ? `${label}: ${detail.slice(0, 300)}` : `${label}. Check your URL, key, and account access.`, response.status);
}

export function routeErrorResponse(error: unknown, fallback: string): Response {
  if (error instanceof RouteError) {
    return Response.json({ error: error.message }, { status: error.status >= 400 && error.status <= 599 ? error.status : 502 });
  }
  if (error instanceof Error && (error.name === "AbortError" || error.name === "TimeoutError")) {
    return Response.json({ error: "The request timed out. Please try again." }, { status: 504 });
  }
  return Response.json({ error: fallback }, { status: 502 });
}
