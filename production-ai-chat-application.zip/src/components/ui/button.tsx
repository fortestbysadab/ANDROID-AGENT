"use client";

import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

export const buttonVariants = cva(
  "inline-flex shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)] focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-45 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)] shadow-[0_3px_10px_rgba(105,86,214,0.18)]",
        secondary: "bg-[var(--soft-bg)] text-[var(--fg)] hover:bg-[var(--hover-bg)]",
        outline: "border border-[var(--border)] bg-[var(--surface)] text-[var(--fg)] hover:bg-[var(--hover-bg)]",
        ghost: "text-[var(--muted)] hover:bg-[var(--hover-bg)] hover:text-[var(--fg)]",
        destructive: "bg-[#e05252] text-white hover:bg-[#c83f3f]",
        soft: "bg-[var(--accent-soft)] text-[var(--accent)] hover:bg-[var(--accent-soft-hover)]",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-8 rounded-lg px-3 text-xs",
        lg: "h-11 px-5",
        icon: "h-10 w-10 p-0",
        "icon-sm": "h-8 w-8 rounded-lg p-0",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  },
);

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, type = "button", ...props }, ref) => (
    <button ref={ref} type={type} className={cn(buttonVariants({ variant, size }), className)} {...props} />
  ),
);
Button.displayName = "Button";
