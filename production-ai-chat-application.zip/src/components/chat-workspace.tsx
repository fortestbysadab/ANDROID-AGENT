"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowRight, BookOpen, Code2, Lightbulb, Menu, PenLine, ShieldCheck, Trash2 } from "lucide-react";
import { Toaster, toast } from "sonner";
import { BrandMark } from "@/components/brand-mark";
import { ChatComposer } from "@/components/chat-composer";
import { ChatMessages } from "@/components/chat-messages";
import { ChatSidebar } from "@/components/chat-sidebar";
import { ModelPicker } from "@/components/model-picker";
import { ProviderSettings } from "@/components/provider-settings";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogTitle } from "@/components/ui/dialog";
import { fetchProviderModels, searchWeb, streamCompletion } from "@/lib/api-client";
import { emptyWorkspace, loadWorkspace, makeConversationTitle, resolveSelectedModel, saveWorkspace } from "@/lib/workspace";
import type { ChatMessage, Conversation, GenerationPhase, ModelSelection, ProviderConfig, ProviderDraft, SearchResult, WorkspaceState } from "@/lib/types";

const suggestions = [
  { icon: Lightbulb, label: "Brainstorm", text: "Help me think of creative ideas for a weekend side project.", tint: "suggestion-purple" },
  { icon: PenLine, label: "Write", text: "Help me write a clear, thoughtful follow-up email after a meeting.", tint: "suggestion-peach" },
  { icon: Code2, label: "Code", text: "Explain how to build a simple REST API with TypeScript, step by step.", tint: "suggestion-blue" },
  { icon: BookOpen, label: "Learn", text: "Explain a complex topic to me using a simple real-world analogy.", tint: "suggestion-green" },
];

function errorMessage(error: unknown): string {
  if (error instanceof Error) {
    if (error.name === "AbortError") return "Request stopped.";
    if (error instanceof TypeError) return "Network error. Check your connection and the provider URL.";
    return error.message;
  }
  return "Something went wrong. Please try again.";
}

export function ChatWorkspace() {
  const [workspace, setWorkspace] = useState<WorkspaceState>(emptyWorkspace);
  const workspaceRef = useRef<WorkspaceState>(emptyWorkspace);
  const [ready, setReady] = useState(false);
  const [dark, setDark] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [clearOpen, setClearOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [phase, setPhase] = useState<GenerationPhase>("idle");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const stickToBottomRef = useRef(true);
  const controllerRef = useRef<AbortController | null>(null);
  const storageWarnedRef = useRef(false);

  const updateWorkspace = useCallback((updater: (previous: WorkspaceState) => WorkspaceState) => {
    const next = updater(workspaceRef.current);
    workspaceRef.current = next;
    setWorkspace(next);
  }, []);

  useEffect(() => {
    const stored = loadWorkspace();
    workspaceRef.current = stored;
    setWorkspace(stored);
    setReady(true);
  }, []);

  // Debounce writes during token streaming; flush once more when the tab closes.
  useEffect(() => {
    if (!ready) return;
    const timer = window.setTimeout(() => {
      if (!saveWorkspace(workspaceRef.current) && !storageWarnedRef.current) {
        storageWarnedRef.current = true;
        toast.error("Browser storage is full. Your latest changes may not be saved.");
      }
    }, 250);
    return () => window.clearTimeout(timer);
  }, [workspace, ready]);

  useEffect(() => {
    if (!ready) return;
    const flush = () => { saveWorkspace(workspaceRef.current); };
    window.addEventListener("pagehide", flush);
    return () => window.removeEventListener("pagehide", flush);
  }, [ready]);

  useEffect(() => {
    if (!ready) return;
    const preference = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      const isDark = workspace.theme === "dark" || (workspace.theme === "system" && preference.matches);
      document.documentElement.classList.toggle("dark", isDark);
      document.documentElement.style.colorScheme = isDark ? "dark" : "light";
      setDark(isDark);
    };
    apply();
    if (workspace.theme === "system") preference.addEventListener("change", apply);
    return () => preference.removeEventListener("change", apply);
  }, [ready, workspace.theme]);

  const activeConversation = workspace.conversations.find((item) => item.id === workspace.activeConversationId);
  const messages = activeConversation?.messages;
  const isGenerating = phase !== "idle";
  const selected = resolveSelectedModel(workspace.providers, workspace.selectedModel);

  useEffect(() => {
    if (!ready || !stickToBottomRef.current || !scrollRef.current) return;
    const frame = requestAnimationFrame(() => {
      if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    });
    return () => cancelAnimationFrame(frame);
  }, [messages, phase, ready]);

  useEffect(() => {
    stickToBottomRef.current = true;
    const frame = requestAnimationFrame(() => {
      if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    });
    return () => cancelAnimationFrame(frame);
  }, [workspace.activeConversationId]);

  const updateAssistant = useCallback((conversationId: string, messageId: string, updater: (message: ChatMessage) => ChatMessage) => {
    updateWorkspace((previous) => ({
      ...previous,
      conversations: previous.conversations.map((conversation) => conversation.id === conversationId
        ? { ...conversation, updatedAt: new Date().toISOString(), messages: conversation.messages.map((message) => message.id === messageId ? updater(message) : message) }
        : conversation),
    }));
  }, [updateWorkspace]);

  function ensureCanGenerate(useSearch: boolean): boolean {
    const current = workspaceRef.current;
    const choice = resolveSelectedModel(current.providers, current.selectedModel);
    if (!choice) {
      toast.info("Connect a provider and select a model to start chatting.");
      setSettingsOpen(true);
      return false;
    }
    const provider = current.providers.find((item) => item.id === choice.providerId);
    if (useSearch && !provider?.searchApiKey) {
      toast.info("Add a web search API key to this provider first.");
      setSettingsOpen(true);
      return false;
    }
    return true;
  }

  const startGeneration = useCallback(async (conversationId: string, history: ChatMessage[], question: string, useSearch: boolean) => {
    if (controllerRef.current) return;
    const current = workspaceRef.current;
    const choice = resolveSelectedModel(current.providers, current.selectedModel);
    const provider = current.providers.find((item) => item.id === choice?.providerId);
    if (!choice || !provider) return;
    const controller = new AbortController();
    controllerRef.current = controller;
    const assistantId = crypto.randomUUID();
    const now = new Date().toISOString();
    const assistant: ChatMessage = {
      id: assistantId, role: "assistant", content: "", createdAt: now, status: "streaming",
      modelId: choice.modelId, providerName: provider.name, usedWebSearch: useSearch,
    };
    setPhase(useSearch ? "searching" : "writing");
    updateWorkspace((previous) => ({
      ...previous,
      conversations: previous.conversations.map((conversation) => conversation.id === conversationId
        ? { ...conversation, updatedAt: now, messages: [...history, assistant] } : conversation),
    }));

    let sources: SearchResult[] = [];
    try {
      if (useSearch) {
        sources = await searchWeb(question, provider.searchEngine, provider.searchApiKey, controller.signal);
        if (controller.signal.aborted) throw new DOMException("Request stopped", "AbortError");
        updateAssistant(conversationId, assistantId, (message) => ({ ...message, citations: sources, searchQuery: question }));
      }
      setPhase("writing");
      await streamCompletion({
        baseUrl: provider.baseUrl,
        apiKey: provider.apiKey,
        model: choice.modelId,
        messages: history.filter((message) => message.content.trim() && message.status !== "error").slice(-80).map((message) => ({ role: message.role, content: message.content })),
        sources,
        searchWasEnabled: useSearch,
        signal: controller.signal,
        onChunk: (text) => updateAssistant(conversationId, assistantId, (message) => ({ ...message, content: message.content + text })),
      });
      updateAssistant(conversationId, assistantId, (message) => ({ ...message, status: "complete" }));
    } catch (error) {
      const stopped = controller.signal.aborted;
      const message = errorMessage(error);
      updateAssistant(conversationId, assistantId, (previous) => ({ ...previous, status: stopped ? "stopped" : "error", error: stopped ? undefined : message }));
      if (!stopped) toast.error("Could not generate a response", { description: message });
    } finally {
      if (controllerRef.current === controller) {
        controllerRef.current = null;
        setPhase("idle");
      }
    }
  }, [updateAssistant, updateWorkspace]);

  const stopGeneration = useCallback(() => { controllerRef.current?.abort(); }, []);

  const newChat = useCallback(() => {
    controllerRef.current?.abort();
    updateWorkspace((previous) => ({ ...previous, activeConversationId: null }));
    setDraft("");
    setEditingId(null);
    setMobileSidebarOpen(false);
    stickToBottomRef.current = true;
    window.setTimeout(() => inputRef.current?.focus(), 0);
  }, [updateWorkspace]);

  useEffect(() => {
    const handleShortcut = (event: globalThis.KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "j") {
        event.preventDefault();
        newChat();
      }
    };
    window.addEventListener("keydown", handleShortcut);
    return () => window.removeEventListener("keydown", handleShortcut);
  }, [newChat]);

  function selectConversation(id: string) {
    if (id !== workspaceRef.current.activeConversationId) controllerRef.current?.abort();
    updateWorkspace((previous) => ({ ...previous, activeConversationId: id }));
    setDraft("");
    setEditingId(null);
    setMobileSidebarOpen(false);
    stickToBottomRef.current = true;
  }

  function sendMessage() {
    const text = draft.trim();
    if (!text || controllerRef.current) return;
    if (!ensureCanGenerate(workspaceRef.current.webSearchEnabled)) return;
    const current = workspaceRef.current;
    const existing = current.conversations.find((item) => item.id === current.activeConversationId);
    const id = existing?.id || crypto.randomUUID();
    const now = new Date().toISOString();
    const userMessage: ChatMessage = { id: crypto.randomUUID(), role: "user", content: text, createdAt: now, status: "complete" };
    const history = [...(existing?.messages || []), userMessage];
    const conversation: Conversation = existing
      ? { ...existing, messages: history, updatedAt: now }
      : { id, title: makeConversationTitle(text), createdAt: now, updatedAt: now, messages: history };
    updateWorkspace((previous) => ({
      ...previous,
      activeConversationId: id,
      conversations: existing ? previous.conversations.map((item) => item.id === id ? conversation : item) : [conversation, ...previous.conversations],
    }));
    setDraft("");
    stickToBottomRef.current = true;
    void startGeneration(id, history, text, current.webSearchEnabled);
    window.setTimeout(() => inputRef.current?.focus(), 0);
  }

  function editAndResend() {
    if (!editingId || !editText.trim() || controllerRef.current) return;
    const current = workspaceRef.current;
    if (!ensureCanGenerate(current.webSearchEnabled)) return;
    const conversation = current.conversations.find((item) => item.id === current.activeConversationId);
    if (!conversation) return;
    const index = conversation.messages.findIndex((message) => message.id === editingId && message.role === "user");
    if (index < 0) return;
    const text = editText.trim();
    const history = [...conversation.messages.slice(0, index), { ...conversation.messages[index], content: text, createdAt: new Date().toISOString() }];
    updateWorkspace((previous) => ({
      ...previous,
      conversations: previous.conversations.map((item) => item.id === conversation.id
        ? { ...item, title: index === 0 ? makeConversationTitle(text) : item.title, messages: history, updatedAt: new Date().toISOString() }
        : item),
    }));
    setEditingId(null);
    stickToBottomRef.current = true;
    void startGeneration(conversation.id, history, text, current.webSearchEnabled);
  }

  function regenerate(messageId: string) {
    if (controllerRef.current) return;
    const current = workspaceRef.current;
    const conversation = current.conversations.find((item) => item.id === current.activeConversationId);
    if (!conversation) return;
    const index = conversation.messages.findIndex((message) => message.id === messageId && message.role === "assistant");
    if (index < 0) return;
    const userIndex = conversation.messages.slice(0, index).findLastIndex((message) => message.role === "user");
    if (userIndex < 0) return;
    const useSearch = conversation.messages[index].usedWebSearch === true;
    if (!ensureCanGenerate(useSearch)) return;
    const history = conversation.messages.slice(0, userIndex + 1);
    const question = history.at(-1)?.content || "";
    updateWorkspace((previous) => ({
      ...previous,
      conversations: previous.conversations.map((item) => item.id === conversation.id
        ? { ...item, messages: history, updatedAt: new Date().toISOString() } : item),
    }));
    stickToBottomRef.current = true;
    void startGeneration(conversation.id, history, question, useSearch);
  }

  function toggleSearch() {
    const current = workspaceRef.current;
    if (!current.webSearchEnabled && !ensureCanGenerate(true)) return;
    updateWorkspace((previous) => ({ ...previous, webSearchEnabled: !previous.webSearchEnabled }));
  }

  async function saveProvider(draftProvider: ProviderDraft): Promise<{ ok: boolean; error?: string }> {
    const current = workspaceRef.current.providers.find((provider) => provider.id === draftProvider.id);
    const sameConnection = current?.baseUrl === draftProvider.baseUrl && current?.apiKey === draftProvider.apiKey;
    const base: ProviderConfig = {
      ...draftProvider,
      models: sameConnection ? current.models : [],
      lastFetchedAt: sameConnection ? current.lastFetchedAt : undefined,
    };
    updateWorkspace((previous) => {
      const providers = previous.providers.some((item) => item.id === base.id)
        ? previous.providers.map((item) => item.id === base.id ? base : item)
        : [...previous.providers, base];
      return { ...previous, providers, selectedModel: resolveSelectedModel(providers, previous.selectedModel) };
    });
    try {
      const models = await fetchProviderModels(draftProvider);
      updateWorkspace((previous) => {
        const providers = previous.providers.map((item) => item.id === base.id
          ? { ...item, models, lastFetchedAt: new Date().toISOString(), modelError: undefined } : item);
        return { ...previous, providers, selectedModel: resolveSelectedModel(providers, previous.selectedModel) };
      });
      toast.success(`${draftProvider.name} connected`, { description: `${models.length} ${models.length === 1 ? "model" : "models"} fetched from the provider.` });
      return { ok: true };
    } catch (error) {
      const message = errorMessage(error);
      updateWorkspace((previous) => ({
        ...previous,
        providers: previous.providers.map((item) => item.id === base.id ? { ...item, modelError: message } : item),
      }));
      toast.error("Could not fetch models", { description: message });
      return { ok: false, error: message };
    }
  }

  async function refreshProvider(provider: ProviderConfig) {
    try {
      const models = await fetchProviderModels(provider);
      updateWorkspace((previous) => {
        const providers = previous.providers.map((item) => item.id === provider.id
          ? { ...item, models, lastFetchedAt: new Date().toISOString(), modelError: undefined } : item);
        return { ...previous, providers, selectedModel: resolveSelectedModel(providers, previous.selectedModel) };
      });
      toast.success(`${provider.name} models updated`, { description: `${models.length} models available.` });
    } catch (error) {
      const message = errorMessage(error);
      updateWorkspace((previous) => ({ ...previous, providers: previous.providers.map((item) => item.id === provider.id ? { ...item, modelError: message } : item) }));
      toast.error("Model refresh failed", { description: message });
    }
  }

  function deleteProvider(id: string) {
    updateWorkspace((previous) => {
      const providers = previous.providers.filter((item) => item.id !== id);
      return { ...previous, providers, selectedModel: resolveSelectedModel(providers, previous.selectedModel) };
    });
    toast.success("Provider removed");
  }

  function deleteConversation(id: string) {
    const wasActive = workspaceRef.current.activeConversationId === id;
    if (wasActive) controllerRef.current?.abort();
    updateWorkspace((previous) => ({
      ...previous,
      conversations: previous.conversations.filter((item) => item.id !== id),
      activeConversationId: previous.activeConversationId === id ? null : previous.activeConversationId,
    }));
    if (wasActive) setDraft("");
    toast.success("Conversation deleted");
  }

  function clearConversation() {
    controllerRef.current?.abort();
    updateWorkspace((previous) => ({
      ...previous,
      conversations: previous.conversations.map((item) => item.id === previous.activeConversationId
        ? { ...item, title: "New conversation", messages: [], updatedAt: new Date().toISOString() } : item),
    }));
    setClearOpen(false);
    setEditingId(null);
    setDraft("");
    toast.success("Chat cleared");
  }

  if (!ready) {
    return (
      <div className="flex h-[100dvh] w-full bg-[var(--app-bg)]" role="status" aria-label="Loading workspace">
        <div className="hidden w-[270px] shrink-0 border-r border-[var(--border)] bg-[var(--sidebar)] p-6 lg:block"><div className="skeleton-line h-9 w-28 rounded-lg" /><div className="skeleton-line mt-12 h-11 w-full rounded-xl" /><div className="skeleton-line mt-9 h-4 w-24 rounded-md" /><div className="skeleton-line mt-5 h-9 w-full rounded-md" /></div>
        <div className="flex flex-1 flex-col"><div className="h-[72px] border-b border-[var(--border)] px-8 py-5"><div className="skeleton-line h-6 w-40 rounded-md" /></div><div className="flex flex-1 items-center justify-center"><div className="skeleton-line h-14 w-64 rounded-xl" /></div><div className="mx-auto mb-8 h-32 w-[min(740px,90%)] rounded-2xl border border-[var(--border)]" /></div>
      </div>
    );
  }

  return (
    <div className="flex h-[100dvh] w-full overflow-hidden bg-[var(--app-bg)] text-[var(--fg)]">
      {mobileSidebarOpen && <button type="button" aria-label="Close sidebar" onClick={() => setMobileSidebarOpen(false)} className="fixed inset-0 z-30 bg-black/40 lg:hidden" />}
      <ChatSidebar
        conversations={workspace.conversations}
        activeId={workspace.activeConversationId}
        providers={workspace.providers}
        dark={dark}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
        onNewChat={newChat}
        onSelect={selectConversation}
        onRename={(id, title) => updateWorkspace((previous) => ({ ...previous, conversations: previous.conversations.map((item) => item.id === id ? { ...item, title, updatedAt: new Date().toISOString() } : item) }))}
        onDelete={deleteConversation}
        onOpenSettings={() => { setMobileSidebarOpen(false); setSettingsOpen(true); }}
        onToggleTheme={() => updateWorkspace((previous) => ({ ...previous, theme: dark ? "light" : "dark" }))}
      />

      <main className="flex min-w-0 flex-1 flex-col bg-[var(--app-bg)]">
        <header className="flex h-[73px] shrink-0 items-center justify-between gap-3 border-b border-[var(--border)] px-4 sm:px-7 lg:px-9">
          <div className="flex min-w-0 items-center gap-3">
            <Button variant="ghost" size="icon-sm" className="-ml-1 lg:hidden" aria-label="Open sidebar" onClick={() => setMobileSidebarOpen(true)}><Menu className="h-5 w-5" /></Button>
            <div className="min-w-0"><p className="hidden text-[10px] font-semibold uppercase tracking-[0.12em] text-[var(--muted)] sm:block">Workspace <span className="mx-1 text-[var(--border-strong)]">/</span> Chat</p><h2 className="max-w-[180px] truncate text-sm font-semibold tracking-tight sm:mt-0.5 sm:max-w-[330px] sm:text-[15px]">{activeConversation?.title || "New conversation"}</h2></div>
          </div>
          <div className="flex shrink-0 items-center gap-2 sm:gap-3">
            {selected && <span className="hidden items-center gap-1.5 text-[11px] text-[var(--muted)] xl:flex"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Ready</span>}
            <ModelPicker providers={workspace.providers} selectedModel={selected} onChange={(selection: ModelSelection) => updateWorkspace((previous) => ({ ...previous, selectedModel: selection }))} onOpenSettings={() => setSettingsOpen(true)} />
            {messages && messages.length > 0 && <Button variant="ghost" size="icon-sm" aria-label="Clear chat" title="Clear chat" onClick={() => setClearOpen(true)}><Trash2 className="h-[17px] w-[17px]" /></Button>}
          </div>
        </header>

        <div ref={scrollRef} onScroll={(event) => { const element = event.currentTarget; stickToBottomRef.current = element.scrollHeight - element.scrollTop - element.clientHeight < 120; }} className="custom-scrollbar min-h-0 flex-1 overflow-y-auto">
          {messages && messages.length > 0 ? (
            <ChatMessages
              messages={messages}
              phase={phase}
              isGenerating={isGenerating}
              editingId={editingId}
              editText={editText}
              onEditStart={(message) => { setEditingId(message.id); setEditText(message.content); }}
              onEditChange={setEditText}
              onEditCancel={() => setEditingId(null)}
              onEditSave={editAndResend}
              onRegenerate={regenerate}
              onStop={stopGeneration}
            />
          ) : (
            <div className="welcome-area mx-auto flex min-h-full w-full max-w-[850px] flex-col items-center justify-center px-5 pb-7 pt-9 text-center sm:px-8">
              <div className="welcome-orbit relative mb-6"><div className="absolute -inset-5 rounded-full bg-[radial-gradient(circle,rgba(116,94,226,0.13),transparent_70%)]" /><BrandMark size="lg" className="relative rotate-[-8deg] shadow-[0_12px_35px_rgba(99,82,190,0.24)]" /><span className="absolute -right-5 -top-2 h-2.5 w-2.5 rounded-full bg-[#d9cbff]" /><span className="absolute -bottom-1 -left-5 h-1.5 w-1.5 rounded-full bg-[#b7dcd8]" /></div>
              <div className="mb-3 inline-flex items-center gap-1.5 rounded-full border border-[var(--border)] bg-[var(--surface)] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-[var(--accent)]"><span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" /> A little more possibility</div>
              <h1 className="text-[clamp(30px,4vw,42px)] font-semibold leading-[1.14] tracking-[-0.055em]">Where should we begin?</h1>
              <p className="mt-3 max-w-[460px] text-[13px] leading-[1.75] text-[var(--muted)] sm:text-[14px]">A space for your questions, ideas, and everything in between. Pick a starting point or just start typing.</p>
              {!selected && <Button variant="default" size="sm" className="mt-5" onClick={() => setSettingsOpen(true)}>Connect a provider <ArrowRight className="h-3.5 w-3.5" /></Button>}
              <div className="mt-9 grid w-full max-w-[670px] grid-cols-1 gap-2.5 text-left sm:grid-cols-2 sm:gap-3">
                {suggestions.map((suggestion) => {
                  const Icon = suggestion.icon;
                  return <button type="button" key={suggestion.label} onClick={() => { setDraft(suggestion.text); inputRef.current?.focus(); }} className="suggestion-card group flex items-start gap-3.5 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-3.5 text-left transition-all hover:-translate-y-0.5 hover:border-[var(--accent)]/30 hover:shadow-[0_8px_24px_rgba(24,24,45,0.065)] sm:p-4"><span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${suggestion.tint}`}><Icon className="h-[18px] w-[18px]" strokeWidth={1.8} /></span><span className="min-w-0 flex-1"><span className="block text-xs font-semibold text-[var(--fg)] sm:text-[13px]">{suggestion.label}</span><span className="mt-1 block text-[11px] leading-snug text-[var(--muted)] sm:text-xs">{suggestion.text}</span></span><ArrowRight className="mt-1 h-3.5 w-3.5 shrink-0 text-[var(--muted)] opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100" /></button>;
                })}
              </div>
              <div className="mt-8 flex items-center gap-1.5 text-[11px] text-[var(--muted)]"><ShieldCheck className="h-3.5 w-3.5" /> Private by default. Powered by the providers you choose.</div>
            </div>
          )}
        </div>

        <div className="shrink-0 bg-[var(--app-bg)]">
          <ChatComposer value={draft} onChange={setDraft} onSend={sendMessage} onStop={stopGeneration} onToggleSearch={toggleSearch} webSearchEnabled={workspace.webSearchEnabled} isGenerating={isGenerating} hasModel={!!selected} inputRef={inputRef} />
        </div>
      </main>

      <ProviderSettings open={settingsOpen} onOpenChange={setSettingsOpen} providers={workspace.providers} onSave={saveProvider} onRefresh={refreshProvider} onDelete={deleteProvider} />
      <Dialog open={clearOpen} onOpenChange={setClearOpen}>
        <DialogContent><div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-red-50 text-red-500 dark:bg-red-950/30"><Trash2 className="h-5 w-5" /></div><DialogTitle>Clear this chat?</DialogTitle><DialogDescription className="mt-2">All messages in this conversation will be permanently removed from this device. This can&apos;t be undone.</DialogDescription><DialogFooter className="mt-7"><Button variant="outline" onClick={() => setClearOpen(false)}>Cancel</Button><Button variant="destructive" onClick={clearConversation}>Clear chat</Button></DialogFooter></DialogContent>
      </Dialog>
      <Toaster position="bottom-right" theme={dark ? "dark" : "light"} richColors closeButton />
    </div>
  );
}
